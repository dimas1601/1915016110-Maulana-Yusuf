

<?php $__env->startSection("content"); ?>
<div class="row pl-3 pt-2">

              <div class="col-lg-12 pl-3">
                <h5>Data User</h5>
                 <a href="<?php echo e(url('create')); ?>"><button class="btn btn-success d-block mb-2 my-2 mr-2">Tambah User</button></a>
                  <table class="table shadow-0">
                      <thead>
                        <tr class="text-center">
                          <th scope="col">No</th>
                          <th scope="col">Avatar</th>
                          <th scope="col">Nama</th>
                          <th scope="col">Roles</th>
                          <th scope="col">Username</th>
                          <th scope="col">Address</th>
                          <th scope="col">Phone</th>
                          <th scope="col">Status</th>
                          <th scope="col">Aksi</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          $no=1;
                        ?>
                        <?php if($data->isEmpty()): ?>
                          <tr>
                            <td colspan="9" class="text-center">Tidak Ada Data</td>
                          </tr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <tr class="text-center">
                          <td><?php echo e($no++); ?></td>
                          <td ><a href="avatar/<?php echo e($user->avatar); ?>" target="_blank"><img width="50%" src="<?php echo e(asset('avatar/'.$user->avatar)); ?>"></a></td>
                          <td><?php echo e($user->name); ?></td>
                          <td><?php echo e($user->roles); ?></td>
                          <td><?php echo e($user->username); ?></td>
                          <td><?php echo e($user->address); ?></td>
                          <td><?php echo e($user->phone); ?></td>
                          <td><?php echo e($user->status); ?></td>
                          <td style="display: flex; margin: 5px;">
                            <a href="<?php echo e(url('edit/'.$user->id)); ?>">
                              <button class="btn btn-warning d-block mb-2 mr-2">Update</button>
                            </a>
                            <a href="<?php echo e(url('delete/'.$user->id)); ?>" onclick="return confirm('Yakin Ingin Menghapus?')">
                              <button class="btn btn-danger d-block mb-2">Delete</button>
                            </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
                </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\manajemen_user\manajemen_user\resources\views/users/users.blade.php ENDPATH**/ ?>